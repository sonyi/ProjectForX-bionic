/** Automatically generated file. DO NOT MODIFY */
package com.yangyu.myslidingmenudemo05;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}