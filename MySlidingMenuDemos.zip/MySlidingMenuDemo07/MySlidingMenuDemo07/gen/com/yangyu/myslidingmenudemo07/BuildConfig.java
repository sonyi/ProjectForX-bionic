/** Automatically generated file. DO NOT MODIFY */
package com.yangyu.myslidingmenudemo07;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}