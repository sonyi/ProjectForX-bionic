/** Automatically generated file. DO NOT MODIFY */
package com.yangyu.myslidingmenudemo04;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}