package com.example.teaching.entity;

import com.example.teaching.fragment.TabViewFragment;

public class TabMenu {
	// ����
	private String name;
	// ͼ��
	private int icon;
	// ѡ��ͼ��
	private int iconSelected;
	// ������ɫ
	private int textColor;
	// ѡ��������ɫ
	private int textColorSelected;
	// ����
	private int background;
	// ѡ�б���
	private int backgroundSelected;
	// tab��ǩ��Ӧ��tab����
	private TabViewFragment tabViewFragment;
	// ѡ��״̬
	private boolean selected;

	public TabMenu(String name, int icon, int iconSelected, int textColor,
			int textColorSelected) {
		this.name = name;
		this.icon = icon;
		this.iconSelected = iconSelected;
		this.textColor = textColor;
		this.textColorSelected = textColorSelected;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIcon() {
		return icon;
	}

	public void setIcon(int icon) {
		this.icon = icon;
	}

	public int getIconSelected() {
		return iconSelected;
	}

	public void setIconSelected(int iconSelected) {
		this.iconSelected = iconSelected;
	}

	public int getTextColor() {
		return textColor;
	}

	public void setTextColor(int textColor) {
		this.textColor = textColor;
	}

	public int getTextColorSelected() {
		return textColorSelected;
	}

	public void setTextColorSelected(int textColorSelected) {
		this.textColorSelected = textColorSelected;
	}

	public int getBackground() {
		return background;
	}

	public void setBackground(int background) {
		this.background = background;
	}

	public int getBackgroundSelected() {
		return backgroundSelected;
	}

	public void setBackgroundSelected(int backgroundSelected) {
		this.backgroundSelected = backgroundSelected;
	}

	public TabViewFragment getTabViewFragment() {
		return tabViewFragment;
	}

	public void setTabViewFragment(TabViewFragment tabViewFragment) {
		this.tabViewFragment = tabViewFragment;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

}
