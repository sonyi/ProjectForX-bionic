package com.example.teaching.adapter;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.teaching.R;
import com.example.teaching.entity.TabMenu;

public class TabMenuGridAdapter extends BaseAdapter {

	private Activity activity;
	private ArrayList<TabMenu> menus;
	private LayoutInflater layoutInflater;

	public TabMenuGridAdapter(Activity mainActivity, ArrayList<TabMenu> menus) {
		this.activity = mainActivity;
		this.menus = menus;
		layoutInflater = this.activity.getLayoutInflater();
	}

	public int getCount() {
		if (menus != null) {
			return menus.size();
		}
		return 0;
	}

	public Object getItem(int position) {
		return menus.get(position);
	}

	public long getItemId(int position) {
		return 0;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		convertView = layoutInflater.inflate(R.layout.tab_menu_item, null);
		TextView textView = (TextView) convertView
				.findViewById(R.id.tab_menu_item_text);
		ImageView imageView = (ImageView) convertView
				.findViewById(R.id.tab_menu_item_icon);
		TabMenu menu = menus.get(position);
		textView.setText(menu.getName());
		//TabMenuΪѡ��״̬ʱ������ѡ��״̬��ͼ�꣬���ı���ɫ
		if (menu.isSelected()) {
			imageView.setImageResource(menu.getIconSelected());
			textView.setTextColor(menu.getTextColorSelected());
		} else {
			imageView.setImageResource(menu.getIcon());
			textView.setTextColor(menu.getTextColor());
		}
		return convertView;
	}

}
