package com.example.teaching.constant;

import java.util.ArrayList;

import com.example.teaching.R;
import com.example.teaching.entity.TabMenu;

public class TabMenuConstant {
	//��ʼ��TabMenu�б�����
	public static ArrayList<TabMenu> initMainTabMenus() {
		ArrayList<TabMenu> tabMenus = new ArrayList<TabMenu>();
		TabMenu tabMenu = new TabMenu("tab_1", R.drawable.tab_1,
				R.drawable.tab_1_selected, ColorConstant.tabTextColor,
				ColorConstant.tabSelectedTextColor);
		tabMenus.add(tabMenu);
		tabMenu = new TabMenu("tab_2", R.drawable.tab_2,
				R.drawable.tab_2_selected, ColorConstant.tabTextColor,
				ColorConstant.tabSelectedTextColor);
		tabMenus.add(tabMenu);
		tabMenu = new TabMenu("tab_3", R.drawable.tab_3,
				R.drawable.tab_3_selected, ColorConstant.tabTextColor,
				ColorConstant.tabSelectedTextColor);
		tabMenus.add(tabMenu);
		tabMenu = new TabMenu("tab_4", R.drawable.tab_4,
				R.drawable.tab_4_selected, ColorConstant.tabTextColor,
				ColorConstant.tabSelectedTextColor);
		tabMenus.add(tabMenu);
		tabMenu = new TabMenu("tab_5", R.drawable.tab_5,
				R.drawable.tab_5_selected, ColorConstant.tabTextColor,
				ColorConstant.tabSelectedTextColor);
		tabMenus.add(tabMenu);
		tabMenu = null;
		return tabMenus;
	}
}
