package com.jj.slidingmenu;

public class MenuViewItem {
	private int imageid;
	private String menutitle;
	public MenuViewItem() {
		// TODO Auto-generated constructor stub
	}
	public MenuViewItem(int imageid,String menutitle){
		this.imageid=imageid;
		this.menutitle=menutitle;
	}
	public int getImageid() {
		return imageid;
	}
	public void setImageid(int imageid) {
		this.imageid = imageid;
	}
	public String getMenutitle() {
		return menutitle;
	}
	public void setMenutitle(String menutitle) {
		this.menutitle = menutitle;
	}
	@Override
	public String toString() {
		return "imageid="+this.imageid+" menutitle"+this.menutitle;
	}
}
