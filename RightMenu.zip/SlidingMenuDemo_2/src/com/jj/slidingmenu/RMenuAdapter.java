package com.jj.slidingmenu;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class RMenuAdapter extends BaseAdapter {
	private Context ctx;
	private List<MenuViewItem> list;
	private LayoutInflater inflater;
	public RMenuAdapter() {
		// TODO Auto-generated constructor stub
	}
	public RMenuAdapter(Context context,List<MenuViewItem> list){
		this.ctx=context;
		if(list!=null&&list.size()>0){
			this.list=list;
		}else{
			list=new ArrayList<MenuViewItem>();
		}
		inflater=LayoutInflater.from(context);
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Viewhold viewhold=null;
		MenuViewItem item=list.get(position);
		if(convertView==null){
			convertView=inflater.inflate(R.layout.item, null);
			viewhold=new Viewhold();
			viewhold.iv_item=(ImageView)convertView.findViewById(R.id.iv_item);
			viewhold.tv_item =(TextView)convertView.findViewById(R.id.tv_item);
			convertView.setTag(viewhold);
		}else{
			viewhold=(Viewhold) convertView.getTag();
		}
			viewhold.iv_item.setImageResource(item.getImageid());
			viewhold.tv_item.setText(item.getMenutitle());
		return convertView;
	}
	private class Viewhold{
		private ImageView iv_item;
		private TextView tv_item;
	}
}
